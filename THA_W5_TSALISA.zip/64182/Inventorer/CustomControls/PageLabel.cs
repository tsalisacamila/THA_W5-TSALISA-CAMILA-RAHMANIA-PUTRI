﻿using System.Windows.Forms;

namespace Inventorer.CustomControls
{
    public partial class PageLabel : Label
    {
        public PageLabel()
        {
            InitializeComponent();
        }
    }
}
